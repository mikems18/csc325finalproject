package fastcards;

/**
 * Fill these with your real Firebase project values.
 */
public class FirebaseConfig {
    // From Firebase project settings
    public static final String API_KEY = "YOUR_FIREBASE_WEB_API_KEY";
    public static final String PROJECT_ID = "YOUR_FIREBASE_PROJECT_ID";

    // Base endpoints
    public static final String FIRESTORE_BASE = "https://firestore.googleapis.com/v1";
    public static final String IDP_BASE = "https://identitytoolkit.googleapis.com/v1";
}
