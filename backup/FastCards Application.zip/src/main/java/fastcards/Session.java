package fastcards;

/**
 * Holds the currently signed-in Firebase user.
 */
public class Session {
    private static Session current;

    public final String uid;
    public final String email;
    public final String idToken;

    public Session(String uid, String email, String idToken) {
        this.uid = uid;
        this.email = email;
        this.idToken = idToken;
    }

    public static Session get() {
        return current;
    }

    public static void set(Session s) {
        current = s;
    }

    public static boolean isLoggedIn() {
        return current != null && current.uid != null && !current.uid.isBlank();
    }
}
