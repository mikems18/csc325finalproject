package fastcards;

public class AppState {
    public static Deck currentDeck;
}
