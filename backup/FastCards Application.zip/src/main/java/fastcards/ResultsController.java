package fastcards;

// Not strictly needed with the inline Alerts, but kept as a placeholder
public class ResultsController {
}
